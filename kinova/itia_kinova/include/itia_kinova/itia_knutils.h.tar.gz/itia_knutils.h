// itia::knutils::j2n6s330_handle --- class under which all jaco 2 handle is present

#ifndef __ITIA_KNUTILS___H__
#define __ITIA_KNUTILS___H__

#include <actionlib/client/simple_action_client.h>
#include <control_msgs/FollowJointTrajectoryAction.h>
#include <itia_kinova/support.h>

#include <moveit/move_group_interface/move_group_interface.h>
#include <moveit/planning_scene_interface/planning_scene_interface.h>
#include <moveit/robot_model_loader/robot_model_loader.h>

#include <geometry_msgs/Pose.h>



namespace itia 
{  
namespace knutils
{

class j2n6s330_handle
{
public:
  j2n6s330_handle(const bool gazebo, ros::NodeHandle& node);  
  ~j2n6s330_handle();
  
  //varaibles 
  const std::string ns;
  const std::string arm_planning_group_name;
  const std::string hand_planning_group_name;
  moveit::planning_interface::MoveGroupInterface group_arm;  //srdf
  moveit::planning_interface::MoveGroupInterface group_hand;  
  robot_model_loader::RobotModelLoader robot_model_loader; //launch file 
  
  //functions
  bool armKinovaMoveTo(const std::vector<double>& joint_positions, 
                        const double& time,
                        const double& path_tolerance=0.005,
                        const double& goal_tolerance=0.01 );
  bool armKinovaMoveToHome();
  bool handKinovaMoveTo(const std::vector<double>& joint_positions, 
                        const double& time,
                        const double& path_tolerance=0.005,
                        const double& goal_tolerance=0.01 );  
  bool handKinovaClose();
  bool handKinovaOpen();
  bool handKinovaGrasp(const std::string obj_id);  
  bool handKinovaUngrasp(const std::string obj_id);
  
  void getCurrentState(std::vector<double>& start_joint_values);
  bool invKin(const geometry_msgs::Pose& best_grasp_pose, std::vector<double>& best_grasp_joint);
  bool allowCollisionsWithObj(const std::string obj_name);
  bool checkRobotCollisionsInPose(const std::vector<double>& poseToBeChecked);
  bool planTrajectory(const std::vector<double>& goal,                            
                      moveit::planning_interface::MoveGroupInterface::Plan& my_plan,
                      const int nb_trials=1);
  bool displayTrajectory(const moveit::planning_interface::MoveGroupInterface::Plan& my_plan);
  bool displayTrajectoryLine(const moveit::planning_interface::MoveGroupInterface::Plan& my_plan,
                             moveit_visual_tools::MoveItVisualToolsPtr& visual_tools_);
  bool executeTrajectory(const moveit::planning_interface::MoveGroupInterface::Plan& my_plan);
  
  
private:
  std::string hand_controller_topic;
  std::string arm_controller_topic;
  std::vector<std::string> arm_joint_names;  
  std::vector<std::string> hand_joint_names; 
  ros::NodeHandle& nh;
  
};

j2n6s330_handle::j2n6s330_handle(const bool gazebo, ros::NodeHandle& node)
  : nh(node), ns(""), arm_planning_group_name("arm"), hand_planning_group_name("gripper"),
    group_arm(arm_planning_group_name), group_hand(hand_planning_group_name), 
    robot_model_loader("robot_description")
{
  if (gazebo)
  {
    arm_controller_topic  = "/j2n6s300/effort_joint_trajectory_controller/follow_joint_trajectory";
    hand_controller_topic = "/j2n6s300/effort_finger_trajectory_controller/follow_joint_trajectory";
  }
  else
  {
    arm_controller_topic  = "/j2n6s300/follow_joint_trajectory";
    hand_controller_topic = "/j2n6s300_gripper/gripper_command";
  }
  
  arm_joint_names  = {"j2n6s300_joint_1", "j2n6s300_joint_2", "j2n6s300_joint_3", 
                      "j2n6s300_joint_4", "j2n6s300_joint_5", "j2n6s300_joint_6"};  
  hand_joint_names = {"j2n6s300_joint_finger_1", "j2n6s300_joint_finger_2", "j2n6s300_joint_finger_3"};
}

j2n6s330_handle::~j2n6s330_handle(){};

bool j2n6s330_handle::armKinovaMoveTo(const std::vector<double>& joint_positions, 
                                      const double& time,
                                      const double& path_tolerance,
                                      const double& goal_tolerance)
{
  
  bool res= itia::support::moveTo(nh,                                   
                                  joint_positions,
                                  arm_joint_names,
                                  time,
                                  arm_controller_topic,
                                  path_tolerance,
                                  goal_tolerance);
  return res;
}

bool j2n6s330_handle::armKinovaMoveToHome()
{
  std::vector<double> joint_positions = {-1.4785, -2.92482, 1.002, -2.08, 1.4458, 1.3233};         
  //std::vector<double> joint_positions = {0.0, -3.14, -1.21, 0.0, 0.0, 0.0};   
  bool res= armKinovaMoveTo(joint_positions,30);
  return res;  
}

bool j2n6s330_handle::handKinovaMoveTo(const std::vector<double>& joint_positions, 
                                      const double& time,
                                      const double& path_tolerance,
                                      const double& goal_tolerance )
{
  bool res= itia::support::moveTo(nh,                                   
                                  joint_positions,
                                  hand_joint_names,
                                  time,
                                  hand_controller_topic,
                                  path_tolerance,
                                  goal_tolerance);
  return res;
}

bool j2n6s330_handle::handKinovaClose()
{
  std::vector<double> joint_positions = {2.0, 2.0, 2.0}; 
  bool res= handKinovaMoveTo(joint_positions,15);
  return res;  
}

bool j2n6s330_handle::handKinovaOpen()
{
  std::vector<double> joint_positions = {0.0, 0.0, 0.0}; 
  bool res= handKinovaMoveTo(joint_positions,15);
  return res;  
}

void j2n6s330_handle::getCurrentState(std::vector<double>& start_joint_values)
{
  group_arm.getCurrentState()->copyJointGroupPositions(group_arm.getCurrentState()->getRobotModel()->getJointModelGroup(group_arm.getName()), start_joint_values);
}

/*    itia::support::allowCollisions(robot_model_loader,"bottle", hand_planning_group_name);
    
    if (itia::support::checkCollisions(robot_model,arm_planning_group_name,best_grasp_joint))
      return -1;*/

bool j2n6s330_handle::invKin(const geometry_msgs::Pose& best_grasp_pose, std::vector<double>& best_grasp_joint)
{
  return itia::support::invKin(best_grasp_pose,robot_model_loader,arm_planning_group_name,best_grasp_joint);
}

bool j2n6s330_handle::allowCollisionsWithObj(const std::string obj_name)
{
  itia::support::allowCollisions(robot_model_loader,"bottle", hand_planning_group_name);
}

// // bool j2n6s330_handle::checkRobotCollisionsInPose(const std::vector<double>& poseToBeChecked)
// // {
// //   robot_model::RobotModelConstPtr robot_model = robot_model_loader.getModel();
// //   if (itia::support::checkCollisions(robot_model,arm_planning_group_name,poseToBeChecked))
// //       return true;
// // }

bool j2n6s330_handle::planTrajectory(const std::vector<double>& goal,                            
                           moveit::planning_interface::MoveGroupInterface::Plan& my_plan,
                           const int nb_trials)
{
    bool plan_ok=false;
    int test = 0;
    itia::support::setTrajectoryPlan(group_arm, goal, my_plan);
    do{
      plan_ok = itia::support::trajectoryPlan(group_arm, my_plan);
      test++;
    }while(!plan_ok && test<nb_trials);
    if (!plan_ok)
    {
      ROS_ERROR("Not able to identify a plan");
      return false;
    }
    if (plan_ok)
    {
      ROS_INFO(" ");
      ROS_INFO("%s Success!! Success!! Success!! Success", BOLDGREEN );
      ROS_INFO(" ");
      return true;
    }
}

bool j2n6s330_handle::displayTrajectory(const moveit::planning_interface::MoveGroupInterface::Plan& my_plan)
{
  ros::Publisher display_publisher = nh.advertise<moveit_msgs::DisplayTrajectory>("/move_group/display_planned_path", 1, true);
  moveit_msgs::DisplayTrajectory display_trajectory;
  display_trajectory.trajectory_start = my_plan.start_state_;
  display_trajectory.trajectory.push_back(my_plan.trajectory_);
  display_publisher.publish(display_trajectory);
  
  sleep(1.0);
}

bool j2n6s330_handle::displayTrajectoryLine(const moveit::planning_interface::MoveGroupInterface::Plan& my_plan,
                                            moveit_visual_tools::MoveItVisualToolsPtr& visual_tools_)
{
  const robot_state::JointModelGroup *joint_model_group = group_arm.getCurrentState()->getJointModelGroup(group_arm.getName());
  visual_tools_->publishTrajectoryLine(my_plan.trajectory_, joint_model_group);
  visual_tools_->trigger();  
  sleep(1.0);
}

bool j2n6s330_handle::executeTrajectory(const moveit::planning_interface::MoveGroupInterface::Plan& my_plan)
{
  group_arm.execute(my_plan);  
  
  /*
  
  if(fake)
    group_arm.execute(my_plan);  
  else
  {        
    if (gazebo)
    {
      group_arm.execute(my_plan); 
    }
    else
    {
      Client client("/j2n6a300_driver/joints_action/joint_angles", true); // true -> don't need ros::spin()
      client.waitForServer();
      
      kinova_msgs::ArmJointAnglesGoal goal;
      
      for( int x = 0; x< my_plan.trajectory_.joint_trajectory.points.size(); x++ )
      {  
        
        goal.angles.joint1 = my_plan.trajectory_.joint_trajectory.points[x].positions[0] * 180 / M_PI ;
        goal.angles.joint2 = my_plan.trajectory_.joint_trajectory.points[x].positions[1] * 180 / M_PI ;
        goal.angles.joint3 = my_plan.trajectory_.joint_trajectory.points[x].positions[2] * 180 / M_PI ;
        goal.angles.joint4 = my_plan.trajectory_.joint_trajectory.points[x].positions[3] * 180 / M_PI ;
        goal.angles.joint5 = my_plan.trajectory_.joint_trajectory.points[x].positions[4] * 180 / M_PI ;
        goal.angles.joint6 = my_plan.trajectory_.joint_trajectory.points[x].positions[5] * 180 / M_PI ;
        
        //std::cout << goal.angles << std::endl ;

        client.sendGoal(goal);
        client.waitForResult(ros::Duration(5.0));
        if (client.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
            ROS_INFO("%s Goal %d Completed", BOLDGREEN, x );
      
        //printf("Current State: %s\n", client.getState().toString().c_str());
      }
    }
  }*/
}

bool j2n6s330_handle::handKinovaGrasp(const std::string obj_id)
{
  bool ok = handKinovaClose(); 
  if (ok)
    ok = group_arm.attachObject(obj_id); 

  ros::Duration(1.0).sleep();
  return ok;
}

bool j2n6s330_handle::handKinovaUngrasp(const std::string obj_id)
{
  bool ok = handKinovaOpen(); 
  if (ok)
    ok = group_arm.detachObject(obj_id);
      
  ros::Duration(1.0).sleep();
  return ok;  
}

}

}

#endif