#ifndef __ITIA_FILE_UTILS__
#define __ITIA_FILE_UTILS__

#include <sys/types.h>
#include <dirent.h>

#include <string>
#include <vector>
#include <iostream>

#define __FUNCFILE__ (strrchr(__FILE__,'/') ? strrchr(__FILE__,'/') + 1 : __FILE__ )

static const char* DEFAULT      = "\033[0m";
static const char* RESET        = "\033[0m";
static const char* BLACK        = "\033[30m";
static const char* RED          = "\033[31m";
static const char* GREEN        = "\033[32m";
static const char* YELLOW       = "\033[33m";
static const char* BLUE         = "\033[34m";
static const char* MAGENTA      = "\033[35m";
static const char* CYAN         = "\033[36m";
static const char* WHITE        = "\033[37m";
static const char* BOLDBLACK    = "\033[1m\033[30m";
static const char* BOLDRED      = "\033[1m\033[31m";
static const char* BOLDGREEN    = "\033[1m\033[32m";
static const char* BOLDYELLOW   = "\033[1m\033[33m";
static const char* BOLDBLUE     = "\033[1m\033[34m";
static const char* BOLDMAGENTA  = "\033[1m\033[35m";
static const char* BOLDCYAN     = "\033[1m\033[36m";
static const char* BOLDWHITE    = "\033[1m\033[37m";

namespace itia
{
namespace futils
{
  inline std::string check_colors()
  {
    std::string ret; 
    ret += std::string( DEFAULT      ); 
    ret += std::string( RESET        ); 
    ret += std::string( BLACK        ); 
    ret += std::string( RED          ); 
    ret += std::string( GREEN        ); 
    ret += std::string( YELLOW       ); 
    ret += std::string( BLUE         ); 
    ret += std::string( MAGENTA      ); 
    ret += std::string( CYAN         ); 
    ret += std::string( WHITE        ); 
    ret += std::string( BOLDBLACK    ); 
    ret += std::string( BOLDRED      ); 
    ret += std::string( BOLDGREEN    ); 
    ret += std::string( BOLDYELLOW   ); 
    ret += std::string( BOLDBLUE     ); 
    ret += std::string( BOLDMAGENTA  ); 
    ret += std::string( BOLDCYAN     ); 
    ret += std::string( BOLDWHITE    ); 
    return ret; 
  }
  
  inline int getdir (std::string dir, std::vector<std::string> &files)
  {
    DIR *dp;
    struct dirent *dirp;
    
    if((dp  = opendir(dir.c_str())) == NULL) 
    {
      std::cout << "Error(" << errno << ") opening " << dir << std::endl;
      return errno;
    }

    while ((dirp = readdir(dp)) != NULL) 
      files.push_back( std::string(dirp->d_name) );    
    
    closedir(dp);
    
    return 0;
  }

}
}


#endif